import React from "react";
import Card from "./Card";
const Main = () => {
  return (
    <div className="h-screen w-full">
      <div
        style={{
          backgroundImage:
            "url(https://images.unsplash.com/photo-1505142468610-359e7d316be0?q=80&w=1852&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D)",
        }}
        className="h-screen w-full bg-no-repeat bg-cover gap-2  pl-4 pt-48
            md:
        "
      >
        <h1 className="text-5xl text-white font-bold ">Kerala</h1>
        <p className="text-[#016d78]">The God's Home</p>
      </div>
      <div className="h-screen w-full bg-[#d4cfc8] flex flex-col justify-center">
        <h1 className="text-white text-center font-medium text-3xl ">
         Travelling To Kerala
        </h1>
        <p className="text-white text-center">A Travel Blog</p>
        <p className="text-white p-4 text-lg"> 
          We look to provide the most authentic contentt from athletes,
          adventuren, explorers travellers autound the Kerala. Our long them
          mission is to educate inspire and enuble all peoples to experience &
          protect wildeness.
        </p>
      </div>
    
    <div className="h-auto flex flex-col items-center justify-start bg-[#d4cfc8]">
        <Card src={"boat.jpg"} head="Kerala" para="a traditional houseboat "/>
        <Card src={"forest1.jpeg"}  head="Kerala" para="a beautiful secluded beach with lush greenery and a stunning sunset"/>
        <Card src={"waves2.jpg"}  head="Kerala" para="a tropical beach with palm trees, white sand, and clear blue water."/>


    </div>
    </div>
  );
};

export default Main;
