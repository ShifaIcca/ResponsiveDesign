import React from 'react'
import Main from './component/Main'

const App = () => {
  return (
    <div >
      <Main/>
    </div>
  )
}

export default App